int pwm_a = 3;
int pwm_b = 9;
int dir_a = 2;
int dir_b = 8;
int tps_depart = 2600;
int tps_final  = 800;
int pas        = 100;
int nb_cycles  = 20;
boolean avant  = true;

void setup() {
  pinMode(pwm_a, OUTPUT);
  pinMode(pwm_b, OUTPUT);
  pinMode(dir_a, OUTPUT);
  pinMode(dir_b, OUTPUT); 
  Serial.begin(9600);
}

void loop() {
  for (int tps = tps_depart; tps >= tps_final; tps -= pas)
  {
    Serial.println(tps);
    for (int i = 0; i < nb_cycles; i++)
    {
      if (avant == true)
      {
        analogWrite(pwm_a, 255);
        analogWrite(pwm_b, 0);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 0);
        analogWrite(pwm_b, 255);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 255);
        analogWrite(pwm_b, 0);
        digitalWrite(dir_a, HIGH);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 0);
        analogWrite(pwm_b, 255);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, HIGH);
        
        delayMicroseconds(tps);
      }
      else
      {
        analogWrite(pwm_a, 0);
        analogWrite(pwm_b, 255);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, HIGH);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 255);
        analogWrite(pwm_b, 0);
        digitalWrite(dir_a, HIGH);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 0);
        analogWrite(pwm_b, 255);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
        
        analogWrite(pwm_a, 255);
        analogWrite(pwm_b, 0);
        digitalWrite(dir_a, LOW);
        digitalWrite(dir_b, LOW);
        
        delayMicroseconds(tps);
      }
    }
  }

  Serial.println(tps_final);

  while (true) 
  {
    if (Serial.available() > 0) 
    {
      char commande = Serial.read();

      if (commande == 'R') 
      {
        avant = true;
        return;
      }

      if (commande == 'T')
      {
        avant = false;
        return;
      }

      if (commande == 'S')
      {
        analogWrite(pwm_a, 0);
        analogWrite(pwm_b, 0);
        
        char rep = 0;
        while (rep != 'R' && rep != 'T')
        {
          delay(10);
          if (Serial.available() > 0)
          {
            rep = Serial.read();
          }
        }
        if (rep == 'T')
        {
          avant = false;
        }
        else
        {
          avant = true;
        }
        return;
      }

      if (commande == 'A' && avant == false)
      {
        for (int tps = tps_final; tps <= tps_depart; tps = tps + pas)
        {
          for (int i = 0; i < 5; i++) 
          {
            analogWrite(pwm_a, 0); 
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, HIGH);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255); 
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, HIGH); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0); 
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255); 
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, LOW);
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
          }
        }
        avant = true;
        for (int tps = tps_depart; tps >= tps_final; tps -= pas) 
        {
          for (int i = 0; i < 5; i++)
          {
            analogWrite(pwm_a, 255); 
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0); 
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW);
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255);
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, HIGH);
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0);
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, HIGH);
            
            delayMicroseconds(tps);
          }
        }
      }

      if (commande == 'B' && avant == true)
      {
        for (int tps = tps_final; tps <= tps_depart; tps += pas)
        {
          for (int i = 0; i < 5; i++) 
          {
            analogWrite(pwm_a, 255);
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, LOW);
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0);
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255);
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, HIGH);
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0);
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW);
            digitalWrite(dir_b, HIGH);
            
            delayMicroseconds(tps);
          }
        }
        avant = false;
        
        for (int tps = tps_depart; tps >= tps_final; tps -= pas) 
        {
          for (int i = 0; i < 5; i++) 
          {
            analogWrite(pwm_a, 0); 
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, HIGH);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255); 
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, HIGH); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 0); 
            analogWrite(pwm_b, 255);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
            
            analogWrite(pwm_a, 255); 
            analogWrite(pwm_b, 0);
            digitalWrite(dir_a, LOW); 
            digitalWrite(dir_b, LOW);
            
            delayMicroseconds(tps);
          }
        }
      }
    }

    if (avant == true) 
    {
      analogWrite(pwm_a, 255); 
      analogWrite(pwm_b, 0);
      digitalWrite(dir_a, LOW); 
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 0); 
      analogWrite(pwm_b, 255);
      digitalWrite(dir_a, LOW); 
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 255);
      analogWrite(pwm_b, 0);
      digitalWrite(dir_a, HIGH);
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 0);
      analogWrite(pwm_b, 255);
      digitalWrite(dir_a, LOW);
      digitalWrite(dir_b, HIGH);
      
      delayMicroseconds(tps_final);
    } 
    else 
    {
      analogWrite(pwm_a, 0); 
      analogWrite(pwm_b, 255);
      digitalWrite(dir_a, LOW); 
      digitalWrite(dir_b, HIGH);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 255);
      analogWrite(pwm_b, 0);
      digitalWrite(dir_a, HIGH);
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 0);
      analogWrite(pwm_b, 255);
      digitalWrite(dir_a, LOW);
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
      
      analogWrite(pwm_a, 255); 
      analogWrite(pwm_b, 0);
      digitalWrite(dir_a, LOW); 
      digitalWrite(dir_b, LOW);
      
      delayMicroseconds(tps_final);
    }
  }
}
