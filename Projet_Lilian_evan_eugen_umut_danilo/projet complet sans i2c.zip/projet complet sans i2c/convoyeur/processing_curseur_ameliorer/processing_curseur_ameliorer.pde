import processing.serial.*;

Serial monPort;

float position  = 0;
float vitesse   = 1;

int tps         = 2600;
float tpsAffiche = 2600;

boolean enMarche    = true;
boolean marcheAvant = true;

int curseurX       = 50;
int curseurY       = 250;
int curseurLargeur = 140;
int curseurHauteur = 60;
boolean curseurActif = false;

int dernierEnvoi = 0;

void setup() {
  size(700, 340);
  println(Serial.list());
  monPort = new Serial(this, Serial.list()[0], 9600);
  monPort.bufferUntil('\n');
}

void draw() {
  background(255);

  tpsAffiche = lerp(tpsAffiche, tps, 0.2);

  vitesse = map(tpsAffiche, 2600, 800, 1, 10);
  float vitesseMS = map(tpsAffiche, 2600, 800, 0.045, 0.147);

  if (enMarche) {
    if (marcheAvant) {
      position += vitesse;
      if (position > 40) position = 0;
    } else {
      position -= vitesse;
      if (position < 0) position = 40;
    }
  }

  fill(100);
  noStroke();
  rect(50, 100, 500, 100);

  stroke(180);
  strokeWeight(3);
  for (float x = 50 + position; x < 550; x += 40) {
    line(x, 100, x, 200);
  }

  noStroke();
  fill(70);
  rect(30, 100, 20, 100);
  rect(550, 100, 20, 100);

  fill(255, 0, 0);
  textSize(16);
  text("tps recu : " + tps + " µs", 20, 40);
  text("vitesse  : " + nf(vitesseMS, 1, 3) + " m/s", 20, 65);

  dessinerCurseur(vitesseMS);

  if (enMarche) fill(200, 50, 50);
  else fill(50, 180, 50);

  rect(220, 250, 160, 60);

  fill(255);
  textSize(20);
  textAlign(CENTER, CENTER);

  if (enMarche) text("STOP", 300, 280);
  else text("MARCHE", 300, 280);

  if (marcheAvant) fill(50, 100, 200);
  else fill(200, 100, 50);

  rect(400, 250, 160, 60);

  fill(255);
  if (marcheAvant) text("AVANT", 480, 280);
  else text("ARRIERE", 480, 280);

  textAlign(LEFT, BASELINE);
}

void dessinerCurseur(float v) {
  pushMatrix();
  translate(curseurX, curseurY);

  fill(230);
  noStroke();
  rect(0, 0, curseurLargeur, curseurHauteur, 10);

  fill(100);
  textAlign(CENTER);
  textSize(10);
  text("RÉGLAGE VITESSE", curseurLargeur/2, 15);

  stroke(180);
  strokeWeight(4);
  line(15, 35, curseurLargeur-15, 35);

  float xBille = map(tps, 2600, 800, 15, curseurLargeur-15);

  if (curseurActif || 
     (mouseX > curseurX && mouseX < curseurX+curseurLargeur &&
      mouseY > curseurY && mouseY < curseurY+curseurHauteur)) {

    fill(50, 120, 255);
    stroke(50, 120, 255, 100);
    strokeWeight(8);
  } else {
    fill(80, 130, 200);
    noStroke();
  }

  ellipse(xBille, 35, 18, 18);

  fill(50);
  textSize(11);
  text(nf(v, 1, 3) + " m/s", curseurLargeur/2, 54);

  popMatrix();
}

void mousePressed() {
  if (mouseX > curseurX && mouseX < curseurX + curseurLargeur &&
      mouseY > curseurY && mouseY < curseurY + curseurHauteur) {
    curseurActif = true;
  }

  if (mouseX > 220 && mouseX < 380 && mouseY > 250 && mouseY < 310) {
    enMarche = !enMarche;

    if (!enMarche) {
      tps = 2600;
      monPort.write('S');
    } else {
      monPort.write(marcheAvant ? 'R' : 'T');
    }
  }

  if (mouseX > 400 && mouseX < 560 && mouseY > 250 && mouseY < 310) {
    marcheAvant = !marcheAvant;
    monPort.write(marcheAvant ? 'A' : 'B');
  }
}

void mouseDragged() {
  if (curseurActif) {
    int nouvellePosX = constrain(mouseX, curseurX + 15, curseurX + curseurLargeur - 15);

    int nouveauTps = (int) map(nouvellePosX,
                               curseurX + 15,
                               curseurX + curseurLargeur - 15,
                               2600, 800);

    nouveauTps = round(nouveauTps / 10) * 10;

    if (nouveauTps != tps) {
      tps = nouveauTps;

      if (millis() - dernierEnvoi > 50) {
        monPort.write('V');
        monPort.write(str(tps) + '\n');
        dernierEnvoi = millis();
      }
    }
  }
}

void mouseReleased() {
  curseurActif = false;
}

void serialEvent(Serial p) {
  String ligne = trim(p.readStringUntil('\n'));
  if (ligne != null) {
    tps = int(ligne);
  }
}
